/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Garima
 */
package com.chess.gui;

import com.chess.engine.board.Board;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Tile;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class Table {
    private final Board chessBoard;
    private final static Dimension OUTER_FRAME_DIMENSION=new Dimension(600,600);
    private final static Dimension BOARD_PANEL_DIMENSION=new Dimension(400,350);
    private final static Dimension TILE_PANEL_DIMENSION=new Dimension(10,10);
    private final JFrame gameFrame;
    private final BoardPanel boardpanel;
    private static final String defaultpieceImagesPath="art/";
    private final Color lightTileColor = Color.decode("#FFFACD");
    private final Color darkTileColor = Color.decode("#593E1A");
    public Table()
    {
        this.gameFrame=new JFrame("ChessGameJ");
        this.gameFrame.setSize(OUTER_FRAME_DIMENSION);
        this.gameFrame.setLayout(new BorderLayout());
        final JMenuBar tableMenuBar=createTableMenuBar();
        this.gameFrame.setJMenuBar(tableMenuBar);
        this.gameFrame.setVisible(true);
        this.boardpanel=new BoardPanel();
        this.gameFrame.add(this.boardpanel,BorderLayout.CENTER);
        this.chessBoard=Board.createStandardBoard();
    }
    private JMenu createFileMenu()
    {
        final JMenu fileMenu=new JMenu("File");
        final JMenuItem openPGN=new JMenuItem("Load PGN File");
        openPGN.addActionListener((ActionEvent e) -> {
            System.out.println("open up that pgn file");
        });
        fileMenu.add(openPGN);
        
        final JMenuItem exitMenuItem=new JMenuItem("Exit");
        exitMenuItem.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            System.exit(0);
        }
    });
    fileMenu.add(exitMenuItem);
       return fileMenu;
    }
    
    private JMenuBar createTableMenuBar()
    {
        final JMenuBar tableMenuBar=new JMenuBar();
        tableMenuBar.add(createFileMenu());
        return tableMenuBar;
    }
    private class BoardPanel extends JPanel
    {
         final java.util.List<TilePanel> boardTiles;
         BoardPanel()
         {
             super(new GridLayout(8,8));
             this.boardTiles=new ArrayList<>();
             for(int i=0;i<BoardUtils.NUM_TILES;i++)
             {
                 final TilePanel tilePanel=new TilePanel(this,i);
                 this.boardTiles.add(tilePanel);
                 add(tilePanel);
             }
             setPreferredSize(BOARD_PANEL_DIMENSION);
             validate();
         }
    }
    private class TilePanel extends JPanel
    {
       private final int tileId;
       TilePanel(final BoardPanel bp, final int tileId)
       {
           super(new GridBagLayout());
           this.tileId=tileId;
           setPreferredSize(TILE_PANEL_DIMENSION);
           assignTileColor();
           assignTilePieceIcon(chessBoard);
           validate();
       }
private void assignTilePieceIcon(final Board board)
{
    this.removeAll();
    final Tile t=board.getTile(tileId);
    if(t.isTileOccupied())
    {
        try {
            BufferedImage image=ImageIO.read(new File(defaultpieceImagesPath + board.getTile(this.tileId).getPiece().getPieceAlliance().toString().substring(0,1)+ board.getTile(this.tileId).getPiece().toString() + ".gif"));
            add(new JLabel(new ImageIcon(image)));
        } catch (IOException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
        private void assignTileColor() {
          //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         if (BoardUtils.EIGHTH_RANK.get(this.tileId) ||
                BoardUtils.SIXTH_RANK.get(this.tileId) ||
                BoardUtils.FOURTH_RANK.get(this.tileId) ||
                BoardUtils.SECOND_RANK.get(this.tileId)) {
                setBackground(this.tileId % 2 == 0 ? lightTileColor : darkTileColor);
            } else if(BoardUtils.SEVENTH_RANK.get(this.tileId) ||
                      BoardUtils.FIFTH_RANK.get(this.tileId )||
                      BoardUtils.THIRD_RANK.get(this.tileId)  ||
                      BoardUtils.FIRST_RANK.get(this.tileId)) {
                setBackground(this.tileId % 2 != 0 ? lightTileColor : darkTileColor);
            }
        }
    }
}

