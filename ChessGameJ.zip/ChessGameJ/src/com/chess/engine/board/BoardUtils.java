/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.board;

import com.google.common.collect.ImmutableList;
import java.util.List;

public class BoardUtils {

    /**
     *
     */
    public static final List<Boolean> FIRST_COLUMN=initColumn(0);
    public static final List<Boolean> SECOND_COLUMN=initColumn(1);
    public static final List<Boolean> SEVENTH_COLUMN=initColumn(6);
    public static final List<Boolean> EIGTH_COLUMN=initColumn(7);
    public static final List<Boolean> SEVENTH_RANK=initRow(8);
    public static final List<Boolean> SECOND_RANK=initRow(48);
       public static final List<Boolean> EIGHTH_RANK=initRow(0);
    public static final List<Boolean> SIXTH_RANK=initRow(16);
    public static final List<Boolean> FIFTH_RANK=initRow(24);
    public static final List<Boolean> FOURTH_RANK=initRow(32);
    public static final List<Boolean> THIRD_RANK=initRow(40);
        public static final List<Boolean> FIRST_RANK=initRow(48);
 public static final int START_TILE_INDEX = 0;
    public static final int NUM_TILES_PER_ROW = 8;
    public static final int NUM_TILES = 64;
    public static Object INSTANCE;
 
     private static List<Boolean> initColumn(int columnNumber) {
        final Boolean[] column = new Boolean[NUM_TILES];
        for(int i = 0; i < column.length; i++) {
            column[i] = false;
        }
        do {
            column[columnNumber] = true;
            columnNumber += NUM_TILES_PER_ROW;
        } while(columnNumber < NUM_TILES);
        return ImmutableList.copyOf(column);
    }
   private static List<Boolean> initRow(int rowNumber) {
        final Boolean[] row = new Boolean[NUM_TILES];
        for(int i = 0; i < row.length; i++) {
            row[i] = false;
        }
        do {
            row[rowNumber] = true;
            rowNumber++;
        } while(rowNumber % NUM_TILES_PER_ROW != 0);
        return ImmutableList.copyOf(row);
    }


    public static boolean isValidTileCoordinate(final int coordinate) {
        return coordinate >= START_TILE_INDEX && coordinate < NUM_TILES;
    }

    /*public static boolean EIGHTH_RANK(int tileId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
    
}
