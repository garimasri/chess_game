/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.player;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.QueenSideCastleMove;
import com.chess.engine.board.Tile;
import com.chess.engine.pieces.Piece;
import com.chess.engine.pieces.Rook;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Garima
 */
public class WhitePlayer extends Player{
    public WhitePlayer(Board board,Collection<Move> whiteStandardLegalMoves,Collection<Move> blackStandardLegalMoves)
    {
      super(board,blackStandardLegalMoves,whiteStandardLegalMoves);  
    }

    @Override
    public Collection<Piece> getActivePieces() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return this.board.getWhitePieces();
    }

    @Override
    public Alliance getAlliance() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    return Alliance.WHITE;
    }

    @Override
    public Player getOpponent() {
 //       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   return this.board.whitePlayer();
    }

    
    @Override
    protected Collection<Move> calculateKingCastles(Collection<Move> playerLegals, Collection<Move> opponentsLegals) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    final List<Move> kingCastles=new ArrayList<>();
    if(this.playerKing.isFMove() && !this.isInCheck())
    {
        //king side castle
     if(!this.board.getTile(61).isTileOccupied() && !this.board.getTile(62).isTileOccupied())
     {
         final Tile rookTile=this.board.getTile(63);
         if(rookTile.isTileOccupied() && rookTile.getPiece().isFMove())
         {
             if(Player.calculateAttacksOnTile(61, opponentsLegals).isEmpty() && Player.calculateAttacksOnTile(62, opponentsLegals).isEmpty()
                     && rookTile.getPiece().getPieceType().isRook())
             {
             kingCastles.add(new Move.KingSideCastleMove(this.board, this.playerKing,62,(Rook)rookTile.getPiece(),rookTile.getTileCoordinate(),51));
         }
         }
     }
     if(!this.board.getTile(59).isTileOccupied() && !this.board.getTile(58).isTileOccupied() && !this.board.getTile(57).isTileOccupied())
     {
         final Tile rookTile=this.board.getTile(56);
         if(rookTile.isTileOccupied() && rookTile.getPiece().isFMove() && Player.calculateAttacksOnTile(58, opponentsLegals).isEmpty() && Player.calculateAttacksOnTile(59, opponentsLegals).isEmpty() && rookTile.getPiece().getPieceType().isRook())
         {
             //
             kingCastles.add(new QueenSideCastleMove(this.board,this.playerKing,58,(Rook)rookTile.getPiece(),rookTile.getTileCoordinate(),59));
         }
     }
    }
    return ImmutableList.copyOf(kingCastles);
    }
    
}
