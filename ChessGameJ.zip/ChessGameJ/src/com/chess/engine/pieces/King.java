/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.pieces;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Tile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Garima
 */
public class King extends Piece {
    private final static int[] CANDIDATE_MOVE_COORDINATES = {-9,-8,-7,-1,1,7,8,9};

  public  King(final Alliance pieceAlliance,final int piecePosition)
    {
        super(PieceType.KING,pieceAlliance,piecePosition);
    }
    @Override
  public Collection<Move> calculateLegalMoves(final Board board) {
      final List<Move> legalMoves=new ArrayList<>();
      int candidateDestinationCoordinate;
   for(int candidateDestinationOffset: CANDIDATE_MOVE_COORDINATES)
   {
   candidateDestinationCoordinate=this.piecePosition+candidateDestinationOffset;
   if(isFirstColumnExclusion(this.piecePosition,candidateDestinationOffset) || isEigthColumnExclusion(this.piecePosition,candidateDestinationOffset))
   {
       continue;
   }
   if(BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate))
   {
       final Tile candidateDestinationTile=board.getTile(candidateDestinationCoordinate);
       if(!candidateDestinationTile.isTileOccupied())
              {
                  legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));
              }
              else
              {
                  final Piece pieceAtDestination;
                  pieceAtDestination = candidateDestinationTile.getPiece();
                  final Alliance pieceAlliance=pieceAtDestination.getPieceAlliance();
                  if(this.pieceAlliance!=pieceAlliance)
                  {
                     legalMoves.add(new Move.AttackMoves(board,this,candidateDestinationCoordinate,pieceAtDestination));
                  }
              }
   }
   }
return legalMoves;
  }
   private static boolean isFirstColumnExclusion(final int currentPosition,final int candidateOffset)
    {
        return BoardUtils.FIRST_COLUMN.get(currentPosition) && ((candidateOffset==-9) || (candidateOffset==-1) ||(candidateOffset==7));
        
    }
    private static boolean isEigthColumnExclusion(final int currentPosition,final int candidateOffset)
    {
        return BoardUtils.EIGTH_COLUMN.get(currentPosition) && ((candidateOffset==-7) || (candidateOffset==1) ||(candidateOffset==9));
    }
    @Override
    public String toString()
    {
        return Piece.PieceType.KING.toString();
    }
    @Override
     public King movePiece(final Move move) {
       return new King(move.getMovedPiece().getPieceAlliance(),move.getDestinationCoordinate());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
