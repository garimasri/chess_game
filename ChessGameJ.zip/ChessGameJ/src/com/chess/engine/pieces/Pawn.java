/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.pieces;
import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.MajorMove;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Garima
 */
public class Pawn extends Piece {
    private final static int[] CANDIDATE_MOVE_COORDINATES = {8,16,7,9};
    private int currentCandidateOffset;

    public Pawn(Alliance pieceAlliance,int piecePosition) {
         super(PieceType.PAWN,pieceAlliance,piecePosition);
    }
    @Override
      public Collection<Move> calculateLegalMoves(final Board board) {
          
         final List<Move> legalMoves=new ArrayList<>();
         for(final int currenCandidateOffset : CANDIDATE_MOVE_COORDINATES)
         {
       int candidateDestinationCoordinate= this.piecePosition + (this.pieceAlliance.getDirection() * currentCandidateOffset);     
         if(!BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate))
         {
             continue;
         }
         
         if(currentCandidateOffset==8 && !board.getTile(candidateDestinationCoordinate).isTileOccupied())
         {
         legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));
        }
         else
             if(currentCandidateOffset==16 && this.isFMove() && (BoardUtils.SEVENTH_RANK.get(this.piecePosition) && this.pieceAlliance.isBlack()) || (BoardUtils.SECOND_RANK.get(this.piecePosition) && this.pieceAlliance.isWhite())) 
             {
                 final int behindCandidateDestinationCoordinate=this.piecePosition+ (this.pieceAlliance.getDirection() *8);
                 if(!board.getTile(behindCandidateDestinationCoordinate).isTileOccupied() && (!board.getTile(candidateDestinationCoordinate).isTileOccupied())) {                     
                   legalMoves.add(new MajorMove(board,this,candidateDestinationCoordinate));
               }
                 }
             
             else if(currentCandidateOffset==7 && !(BoardUtils.EIGTH_COLUMN.get(this.piecePosition)) && this.pieceAlliance.isWhite() || (BoardUtils.FIRST_COLUMN.get(this.piecePosition) && this.pieceAlliance.isBlack()))
             {
                 if(board.getTile(candidateDestinationCoordinate).isTileOccupied())
                 {
                     final Piece pieceOnCandidate=board.getTile(candidateDestinationCoordinate).getPiece();
                     if(this.pieceAlliance!=pieceOnCandidate.getPieceAlliance())
                     {
                      legalMoves.add(new MajorMove(board,this,candidateDestinationCoordinate));
                     }
                 }
             }
             else if(currentCandidateOffset==9 && !(BoardUtils.FIRST_COLUMN.get(this.piecePosition)) && this.pieceAlliance.isWhite() || (BoardUtils.EIGTH_COLUMN.get(this.piecePosition) && this.pieceAlliance.isBlack()))
             {
                 if(board.getTile(candidateDestinationCoordinate).isTileOccupied())
                 {
                     final Piece pieceOnCandidate=board.getTile(candidateDestinationCoordinate).getPiece();
                     if(this.pieceAlliance!=pieceOnCandidate.getPieceAlliance())
                     {
                        legalMoves.add(new MajorMove(board,this,candidateDestinationCoordinate));
                     }
                 }
         
             }
         }
          return ImmutableList.copyOf(legalMoves);
      
      }
    @Override
      public String toString()
    {
        return Piece.PieceType.PAWN.toString();
    }
    @Override
 public Pawn movePiece(final Move move) {
       return new Pawn(move.getMovedPiece().getPieceAlliance(),move.getDestinationCoordinate());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
}
