/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.pieces;
import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.AttackMoves;
import com.chess.engine.board.Move.MajorMove;
import com.chess.engine.board.Tile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class Bishop extends Piece {

    private final static int[] CANDIDATE_MOVE_COORDINATES = {-9, -7, 7, 9};

    public Bishop(final Alliance pieceAlliance,final int piecePosition) {
         super( PieceType.BISHOP,pieceAlliance, piecePosition);
    }


    @Override
    public Collection<Move> calculateLegalMoves(final Board board) {
        final List<Move> legalMoves = new ArrayList<>();
        for (final int currentCandidateOffset : CANDIDATE_MOVE_COORDINATES) {
            int candidateDestinationCoordinate = this.piecePosition;
            while (BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate)) {
                  if(isFirstColumnExclusion(this.piecePosition,currentCandidateOffset)|| isEighthColumnExclusion(this.piecePosition,currentCandidateOffset))
              {
                  continue;
              }
                candidateDestinationCoordinate += currentCandidateOffset;
               if(BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate))
               {
              final Tile CandidateDestinationTile=board.getTile(candidateDestinationCoordinate);
              if(!CandidateDestinationTile.isTileOccupied())
              {
                 
               legalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
              }
              else
              {
                  final Piece pieceAtDestination;
                  pieceAtDestination = CandidateDestinationTile.getPiece();
                  final Alliance pieceAlliance=pieceAtDestination.getPieceAlliance();
                  if(this.pieceAlliance!=pieceAlliance)
                  {
                    legalMoves.add(new AttackMoves(board,this,candidateDestinationCoordinate,pieceAtDestination));
                  }
              }
              break;
          } 
        }
        }
        return (legalMoves);
    }
    @Override
    public String toString()
    {
        return Piece.PieceType.BISHOP.toString();
    }
    public static boolean isFirstColumnExclusion(final int currentCandidate,
                                                  final int candidateDestinationCoordinate) {
        return (BoardUtils.FIRST_COLUMN.get(candidateDestinationCoordinate) &&
                ((currentCandidate == -9) || (currentCandidate == 7)));
    }

    private static boolean isEighthColumnExclusion(final int currentCandidate,
                                                   final int candidateDestinationCoordinate) {
        return BoardUtils.EIGTH_COLUMN.get(candidateDestinationCoordinate) &&
                        ((currentCandidate == -7) || (currentCandidate == 9));
    }

    @Override
    public Bishop movePiece(final Move move) {
       return new Bishop(move.getMovedPiece().getPieceAlliance(),move.getDestinationCoordinate());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

}