/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess.engine.pieces;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Tile;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Garima
 */
public class Rook extends Piece {
    
    
private final static int[] CANDIDATE_MOVE_COORDINATES = {-8, -1, 1, 8};

    public  Rook(final Alliance pieceAlliance,final int piecePosition) {
         super(PieceType.ROOK,pieceAlliance,piecePosition);
    }

  


    @Override
    public Collection<Move> calculateLegalMoves(final Board board) {
        final List<Move> legalMoves = new ArrayList<>();
        for (final int currentCandidateOffset : CANDIDATE_MOVE_COORDINATES) {
            int candidateDestinationCoordinate = this.piecePosition;
            while (BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate)) {
                  if (isColumnExclusion(currentCandidateOffset, candidateDestinationCoordinate)) 
              {
                break;
              }
                candidateDestinationCoordinate += currentCandidateOffset;
               if(BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate))
               {
              final Tile CandidateDestinationTile=board.getTile(candidateDestinationCoordinate);
              if(!CandidateDestinationTile.isTileOccupied())
              {
                legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));
              }
              else
              {
                  final Piece pieceAtDestination;
                  pieceAtDestination = CandidateDestinationTile.getPiece();
                  final Alliance piecealliance=pieceAtDestination.getPieceAlliance();
                  if(this.pieceAlliance!=piecealliance)
                  {
                     legalMoves.add(new Move.AttackMoves(board,this,candidateDestinationCoordinate,pieceAtDestination));
                  }
              }
              break;
          } 
        }
        }
        return ImmutableList.copyOf(legalMoves);
    }
   
@Override
    public String toString()
    {
        return Piece.PieceType.ROOK.toString();
    }
   private static boolean isColumnExclusion(final int currentCandidate,
                                             final int candidateDestinationCoordinate) {
        return (BoardUtils.FIRST_COLUMN.get(candidateDestinationCoordinate) && (currentCandidate == -1)) ||
               (BoardUtils.EIGTH_COLUMN.get(candidateDestinationCoordinate) && (currentCandidate == 1));
    }

@Override
 public Rook movePiece(final Move move) {
       return new Rook(move.getMovedPiece().getPieceAlliance(),move.getDestinationCoordinate());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
