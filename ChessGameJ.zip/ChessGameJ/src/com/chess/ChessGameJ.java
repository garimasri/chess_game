/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chess;

import com.chess.engine.board.Board;
import static com.chess.engine.board.Board.createStandardBoard;
import com.chess.gui.Table;

/**
 *
 * @author Garima
 */
public class ChessGameJ {
    public static void main(String[] args)
    {
  // Board board =createStandardBoard();
    //System.out.println(board);
    Table table=new Table();
}
}
